# 이진 트리를 사용하여 수식(Expression)을 표현

# 수식 트리(Expression Tree)
# 주로 연산자는 내부 노드에, 피연산자(숫자 또는 변수)는 리프 노드에 위치함

# Node 클래스 정의
#    - 이진 트리의 기본 노드
#    - 여기서는 노드의 key에 연산자 또는 피연산자를 저장함

class Node:
    """수식 트리의 노드를 표현하는 클래스"""
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

# 수식 트리를 이용한 계산 (Evaluation)수식 트리를 계산하려면
# 후위 순회(Postorder Traversal)와 비슷한 방식으로 노드를 방문해야 함
# 리프 노드(피연산자)에서 값을 가져온 다음, 그 부모 노드(연산자)에서 연산을 수행함

def evaluate_expression_tree(root):
    """
    수식 트리를 순회하며 수식의 최종 값을 계산
    """
    
    # 노드가 None이면 0을 반환 (혹은 예외 처리를 할 수 있음)
    if root is None:
        return 0
    
    # 1. 리프 노드 확인 (피연산자)
    # 리프 노드(자식이 없는 노드)는 피연산자(숫자)임

    if root.left is None and root.right is None:
        # 숫자가 문자열일 수 있으므로 정수형으로 변환
        return int(root.key)

    # 2. 내부 노드 확인 (연산자)
    # 왼쪽 및 오른쪽 서브 트리의 값을 재귀적으로 계산함
    left_val = evaluate_expression_tree(root.left)
    right_val = evaluate_expression_tree(root.right)

    # 3. 현재 노드의 연산자를 사용하여 결과를 반환함
    operator = root.key
    print(operator)    

    if operator == '+':
        return left_val + right_val
    elif operator == '-':
        return left_val - right_val
    elif operator == '*':
        return left_val * right_val
    elif operator == '/':

        # 나누기 연산 시 0으로 나누는 경우를 방지함
        if right_val == 0:
            raise ZeroDivisionError("0으로 나눌 수 없습니다.")
        return left_val / right_val
    
    # 지원하지 않는 연산자인 경우 예외 처리
    else:
        raise ValueError(f"지원하지 않는 연산자: {operator}")

# 사용 예시 및 테스트

# 다음 수식 ( (3 * 4) + (5 - 2) )를 표현하는 트리
# --- 수식 트리 구성 ---
# 루트 : +

root = Node('+')

# 왼쪽 서브 트리 : 3 * 4
root.left = Node('*')
root.left.left = Node('3')
root.left.right = Node('4')

# 오른쪽 서브 트리 : 5 - 2
root.right = Node('-')
root.right.left = Node('5')
root.right.right = Node('2')

# --- 계산 실행 ---
try:
    result = evaluate_expression_tree(root)
    print(f"수식 트리: ((3 * 4) + (5 - 2))")
    print(f"결과: {result}")
    
# 예상 계산 : (3 * 4) + (5 - 2) = 12 + 3 = 15
    
except (ZeroDivisionError, ValueError) as e:
    print(f"오류 발생: {e}")

# 수식 트리 시각화 (순회)트리의 구조를 확인하기 위해 세 가지 순회 방식을 사용할 수 있음
# 순회 방식
# 수식 결과
# 전위 (Preorder) - 폴란드 표기법(Prefix)
# 중위 (Inorder) - 일반적인 중위 표기법(Infix)
# 후위 (Postorder) - 역폴란드 표기법 (Postfix)

def inorder_traversal_expression(node):
    """중위 순회: 수식의 괄호를 포함하여 출력"""
    if node:
        # 연산자 노드일 경우 괄호를 추가하여 우선순위를 표현
        if node.left or node.right:
            print("(", end="")
            
        inorder_traversal_expression(node.left)
        
        # 현재 노드 출력
        print(node.key, end="")
        
        inorder_traversal_expression(node.right)
        
        if node.left or node.right:
            print(")", end="")

print("\n--- 수식 트리 시각화 ---")
print("중위 표기법 (Infix):", end=" ")
inorder_traversal_expression(root) # 출력: ((3*4)+(5-2))
print()