# AVL 트리

# 자가 균형 이진 탐색 트리(Self-Balancing Binary Search Tree)의 일종
# 모든 노드에서 왼쪽 서브트리의 높이와 오른쪽 서브트리의 높이 차이(균형 인수, Balance Factor)가 1 이하가 되도록 유지하는 것

# AVL 트리의 특징 및 주된 용도
#   - 탐색, 삽입, 삭제 연산의 최악 시간 복잡도를 O(log n)으로 보장
#   - 동적인 데이터 세트에서 일관되고 빠른 성능을 유지하는 것임

# AVL 트리의 주요 용도 및 장점
#   - AVL 트리는 자가 균형 이진 탐색 트리(Self-Balancing Binary Search Tree, BST) 중 가장 초기에 개발된 형태
#   - 일반적인 이진 탐색 트리가 최악의 경우(데이터가 정렬되어 삽입될 때) O(n)의 시간 복잡도를 가지는 문제를 해결함

#   -  빠른 탐색 성능 보장용도
#        - 데이터베이스의 인덱스, 파일 시스템의 구조 등 데이터를 자주 검색해야 하는 시스템
#        - 트리의 높이 차이가 항상 1 이하로 유지되므로, 트리가 한쪽으로 치우치는 현상(Skewing)이 발생하지 않음
#        - 따라서 탐색 시간은 항상 O(log n)으로 유지됨
#   - 동적 데이터 관리용도
#        - 키-값 쌍을 저장하고 빠르게 접근해야 하는 연관 배열(Associative Array)이나 맵(Map) 구현
#        - 데이터가 끊임없이 삽입되거나 삭제되는 환경에서도 로그 시간(O(log n)) 안에 균형을 재조정함
#        - 이는 잦은 데이터 변경에도 불구하고 검색 성능이 떨어지지 않음을 의미함
#   - 일관된 최악 시간 복잡도 용도
#        - 실시간 시스템이나 성능 예측이 중요한 환경
#        - AVL 트리는 삽입, 삭제, 탐색 모두에서 최악의 경우에도 O(log n)의 성능을 제공함
#        - 이는 모든 연산이 예측 가능한 범위 내에서 완료됨을 보장함

# 노드 및 기본 구조 - 노드 정의, 높이 계산, 균형 인수 계산
# 회전(Rotation) 연산 - AVL 트리의 핵심인 균형을 맞추는 4가지 회전(LL, RR, LR, RL).
# 삽입(Insertion) - 삽입 후 균형을 확인하고 필요하면 회전을 수행


# 노드 및 기본 구조 정의

class AVLNode:
    """AVL 트리의 노드를 정의"""
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1 # 노드의 높이 (새 노드는 리프이므로 높이 1)

class AVLTree:
    """AVL 트리의 주요 로직을 처리하는 클래스"""
    def __init__(self):
        self.root = None
        
    def _get_height(self, node):
        """노드의 높이를 반환, None이면 0을 반환"""
        if not node:
            return 0
        return node.height

    def _get_balance(self, node):
        """노드의 균형 인수(Balance Factor)를 계산"""
        if not node:
            return 0
        # 균형 인수 = 왼쪽 서브트리 높이 - 오른쪽 서브트리 높이
        return self._get_height(node.left) - self._get_height(node.right)

# 회전(Rotation) 연산

# AVL 트리는 균형 인수가 |BF| > 1이 될 때, 즉 2 또는 -2가 될 때 회전 연산을 통해 트리를 재구성함

    def _update_height(self, node):
        """노드의 높이를 갱신"""
        node.height = 1 + max(self._get_height(node.left), 
                              self._get_height(node.right))

    # --- 단일 회전 ---
    def _right_rotate(self, y):
        """RR 회전 (Right-Right Case)과 LR 회전의 첫 단계에 사용"""
        x = y.left
        T2 = x.right

        # 회전 수행
        x.right = y
        y.left = T2

        # 높이 갱신 (순서 중요: y 먼저, 그 다음 x)
        self._update_height(y)
        self._update_height(x)

        return x # 새로운 서브트리의 루트를 반환

    def _left_rotate(self, x):
        """LL 회전 (Left-Left Case)과 RL 회전의 첫 단계에 사용"""
        y = x.right
        T2 = y.left

        # 회전 수행
        y.left = x
        x.right = T2

        # 높이 갱신 (순서 중요: x 먼저, 그 다음 y)
        self._update_height(x)
        self._update_height(y)

        return y # 새로운 서브트리의 루트를 반환


# 삽입(Insertion) 구현
# 일반적인 BST 삽입 후, 재귀 호출을 되돌아오면서 각 조상 노드의 균형을 확인하고 필요시 회전을 적용함.

    def insert(self, root, key):
        """
        키를 삽입하고 필요에 따라 회전하여 균형을 맞춤
        """
        # 1. 일반 BST 삽입 수행
        if not root:
            return AVLNode(key)
        
        if key < root.key:
            root.left = self.insert(root.left, key)
        elif key > root.key:
            root.right = self.insert(root.right, key)
        else:
            return root # 중복 키는 허용하지 않음

        # 2. 현재 노드의 높이 갱신
        self._update_height(root)

        # 3. 균형 인수 계산
        balance = self._get_balance(root)

        # 4. 균형이 깨진 경우 (balance > 1 또는 balance < -1), 4가지 경우 처리
        
        # Case 1: Left Left (LL)
        if balance > 1 and key < root.left.key:
            return self._right_rotate(root)

        # Case 2: Right Right (RR)
        if balance < -1 and key > root.right.key:
            return self._left_rotate(root)

        # Case 3: Left Right (LR)
        if balance > 1 and key > root.left.key:
            root.left = self._left_rotate(root.left) # L 회전 후
            return self._right_rotate(root)           # R 회전

        # Case 4: Right Left (RL)
        if balance < -1 and key < root.right.key:
            root.right = self._right_rotate(root.right) # R 회전 후
            return self._left_rotate(root)            # L 회전

        return root


# 테스트 및 순회
# BST가 잘 구성되었는지 확인하기 위해 중위 순회 함수와 테스트 코드를 추가
    def inorder_traversal(self, root):
        """BST 순회 (정렬된 순서로 출력)"""
        result = []
        if root:
            result.extend(self.inorder_traversal(root.left))
            result.append(root.key)
            result.extend(self.inorder_traversal(root.right))
        return result

# --- AVL 트리 사용 예시 ---
avl = AVLTree()
root = None
keys = [10, 20, 30, 40, 50, 25] # LL, LR, RR 등 다양한 케이스를 유발하는 키

print(f"삽입할 키: {keys}")

for key in keys:
    root = avl.insert(root, key)
    # 삽입 단계별로 트리의 균형이 유지되는 것을 확인하려면 각 삽입 후 출력 로직 추가 가능

print("\n--- 최종 AVL 트리 확인 ---")
print(f"중위 순회 (정렬): {avl.inorder_traversal(root)}")
print(f"새로운 루트 노드: {root.key} (높이: {root.height}, 균형 인수: {avl._get_balance(root)})")
