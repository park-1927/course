# 이진 트리 노드 기반 구현

class Node:
    """이진 트리의 단일 노드를 표현하는 클래스"""
    def __init__(self, key):
        # 노드가 저장하는 데이터
        self.key = key
        # 왼쪽 자식 노드를 가리키는 포인터
        self.left = None
        # 오른쪽 자식 노드를 가리키는 포인터
        self.right = None


# 트리 생성 및 구조화
# Node 클래스를 사용하여 트리의 구조를 직접 만들 수 있음

# 1. 루트 노드 생성
root = Node("A")

# 2. 자식 노드 추가
# 레벨 1
root.left = Node("B")
root.right = Node("C")

# 레벨 2
root.left.left = Node("D")
root.left.right = Node("E")
root.right.right = Node("F")

# 현재 트리의 구조:
#       A
#      / \
#     B   C
#    / \   \
#   D   E   F


# 중위 순회 (Inorder Traversal)
#       왼쪽 -> 루트 -> 오른쪽 순서로 방문
#       이진 검색 트리(BST)에서 중위 순회를 하면 정렬된 순서로 노드를 얻을 수 있음


def inorder_traversal(node):
    if node:
        # 1. 왼쪽 서브 트리 방문
        inorder_traversal(node.left)

        # 2. 현재 노드(루트) 방문 및 출력
        print(node.key, end=" ")

        # 3. 오른쪽 서브 트리 방문
        inorder_traversal(node.right)

print("중위 순회 (Inorder):", end=" ")
inorder_traversal(root) # 출력: D B E A C F 
print()


#. 전위 순회 (Preorder Traversal)
#    - 루트 -> 왼쪽 -> 오른쪽 순서로 방문
#    - 트리를 복사하거나 트리의 구조를 표현할 때 사용됨

def preorder_traversal(node):
    if node:
        # 1. 현재 노드(루트) 방문 및 출력
        print(node.key, end=" ")

        # 2. 왼쪽 서브 트리 방문
        preorder_traversal(node.left)

        # 3. 오른쪽 서브 트리 방문
        preorder_traversal(node.right)

print("전위 순회 (Preorder):", end=" ")
preorder_traversal(root) # 출력: A B D E C F 
print()


# 후위 순회 (Postorder Traversal)
#      - 왼쪽 -> 오른쪽 -> 루트 순서로 방문
#     - 트리를 삭제할 때(자식 노드부터 삭제) 사용됨

def postorder_traversal(node):
    if node:
        # 1. 왼쪽 서브 트리 방문
        postorder_traversal(node.left)
        # 2. 오른쪽 서브 트리 방문
        postorder_traversal(node.right)
        # 3. 현재 노드(루트) 방문 및 출력
        print(node.key, end=" ")

print("후위 순회 (Postorder):", end=" ")
postorder_traversal(root) # 출력: D E B F C A 
print()