"""
 - 내부 경로 길이 - 루트에서 모든 내부 노드(자식이 있는 노드)까지의 경로 길이(깊이)를 모두 더한 값

 - 외부 경로 길이 - 루트에서 모든 외부 노드(리프 노드 또는 확장 이진 트리에서 추가된 null 자식 노드)까지의 경로 길이(깊이)를 모두 더한 값
                           여기서의 외부 노드는 일반적으로 리프 노드를 의미
"""

class Node:

    """이진 트리의 노드를 표현하는 클래스"""
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


def calculate_path_lengths(root):
    """
    이진 트리의 내부 경로 길이와 외부 경로 길이를 계산
    (여기서 외부 노드는 리프 노드를 의미)
    """
    
    # 내부 경로 길이 (Internal Path Length, IPL): 루트에서 각 내부 노드까지의 깊이 합
    internal_path_length = 0

    # 외부 경로 길이 (External Path Length, EPL): 루트에서 각 리프 노드(외부 노드)까지의 깊이 합
    external_path_length = 0
    
    # DFS를 위한 스택: (노드, 현재 깊이)
    stack = [(root, 0)]
    
    while stack:
        current_node, depth = stack.pop()
        
        if current_node is None:
            continue
            
        # 1. 내부 노드 확인 및 IPL 계산
        # 리프 노드가 아니면 내부 노드
        if current_node.left or current_node.right:
            internal_path_length += depth
            
        # 2. 리프 노드(외부 노드) 확인 및 EPL 계산
        # 자식이 없으면 리프 노드(외부 노드)
        if current_node.left is None and current_node.right is None:
            external_path_length += depth
        
        # 3. 다음 탐색을 위해 자식 노드를 스택에 추가
        # 오른쪽 자식을 먼저 넣어야 왼쪽 자식이 먼저 처리됨(스택이 LIFO 방식이므로)
        if current_node.right:
            stack.append((current_node.right, depth + 1))
        if current_node.left:
            stack.append((current_node.left, depth + 1))

    return internal_path_length, external_path_length

# 경로의 길이는 루트에서 해당 노드까지의 간선(edge) 수이며, 
# 이는 곧 노드의 깊이(depth)와 같음
# 루트 노드의 깊이는 0임

#  사용 예시

# 트리 생성 예시
#       1 (깊이 0)  <-- 내부 노드
#      / \
#     2   3 (깊이 1) <-- 내부 노드 (2는 리프가 아니므로), 내부 노드 (3은 리프가 아니므로)
#    / \   \
#   4   5   6 (깊이 2) <-- 리프 노드 (4, 5, 6)
#  /
# 7 (깊이 3) <-- 리프 노드 (7)
#
# * 내부 노드: 1, 2, 3 (자식이 있는 노드)
# * 리프 노드(외부 노드): 4, 5, 6, 7 (자식이 없는 노드)

root = Node(1)
root.left = Node(2)
root.right = Node(3)
root.left.left = Node(4)
root.left.right = Node(5)
root.right.right = Node(6)
root.left.left.left = Node(7)

ipl, epl = calculate_path_lengths(root)

print(f"내부 경로 길이 (IPL): {ipl}")
print(f"외부 경로 길이 (EPL - 리프 노드 기준): {epl}")

# --- 계산 확인 ---
# 내부 경로 길이 (IPL):
# 노드 1 (깊이 0) + 노드 2 (깊이 1) + 노드 3 (깊이 1) = 2
# (노드 4, 5, 6, 7은 자식이 없으므로 내부 노드가 아님)
# IPL = 0 + 1 + 1 = 2
#
# 외부 경로 길이 (EPL - 리프 노드 기준):
# 노드 4 (깊이 2) + 노드 5 (깊이 2) + 노드 6 (깊이 2) + 노드 7 (깊이 3)
# EPL = 2 + 2 + 2 + 3 = 9