#TreeNode 클래스 구현

class TreeNode:

    """일반 트리의 개별 노드를 나타내는 클래스"""
    def __init__(self, data):
        # 노드가 저장하는 데이터
        self.data = data
        # 자식 노드들을 저장할 리스트 (일반 트리는 자식 수에 제한이 없음)
        self.children = []
        # 부모 노드를 참조하여 트리를 위로 거슬러 올라갈 수도 있지만, 여기서는 출력 편의를 위해 생략합니다.

    def add_child(self, child_node):
        """현재 노드의 자식으로 새로운 노드를 추가하는 메서드"""
        self.children.append(child_node)

    def __repr__(self):
        """노드 객체를 출력할 때 데이터 값을 보여주도록 설정"""
        return f"Node({self.data})"

#계층적 출력 함수 (print_tree) 구현
def print_tree(node, level=0):
    """
    트리를 계층적으로 출력하는 함수 (깊이 우선 탐색 방식)

    :param node: 현재 처리 중인 TreeNode 객체
    :param level: 현재 노드의 깊이 (들여쓰기 수준)
    """
    # 들여쓰기를 위한 공백 문자열 (깊이당 탭 4칸)
    indentation = "    " * level
    
    # 현재 노드를 출력
    print(f"{indentation}{node.data}")
    
    # 현재 노드의 모든 자식 노드에 대해 재귀적으로 함수 호출
    # 다음 레벨은 현재 레벨보다 1 증가
    for child in node.children:
        print_tree(child, level + 1)

# 트리 생성 및 출력 예시 
# 회사 조직도를 예시로 트리를 구성하고 출력

# 1. 노드 생성
root = TreeNode("CEO")
cto = TreeNode("CTO")
cfo = TreeNode("CFO")
marketing_vp = TreeNode("VP of Marketing")
hr_director = TreeNode("HR Director")
rnd_lead = TreeNode("R&D Lead")
sales_manager = TreeNode("Sales Manager")
staff1 = TreeNode("Staff 1")
staff2 = TreeNode("Staff 2")

# 2. 트리 구조 연결

# CEO의 직속 부하
root.add_child(cto)
root.add_child(cfo)
root.add_child(marketing_vp)

# CTO의 직속 부하
cto.add_child(rnd_lead)
cto.add_child(hr_director)

# VP of Marketing의 직속 부하
marketing_vp.add_child(sales_manager)

# R&D Lead의 직속 부하
rnd_lead.add_child(staff1)
rnd_lead.add_child(staff2)


# 3. 트리 출력
print("=== 회사 조직도 트리 출력 ===")
print_tree(root)


