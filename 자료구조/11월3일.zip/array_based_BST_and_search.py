# 배열 기반 이진 트리 구현
# 완전 이진 트리(Complete Binary Tree)의 경우, 배열(리스트)을 사용하여 노드를 효율적으로 저장할 수 있음

# 노드의 위치(인덱스)를 통해 부모-자식 관계를 수학적으로 계산함
# 인덱스 규칙 (루트 인덱스 0 기준)특정 노드의 인덱스가 i일 때
#      - 왼쪽 자식 : 2 i + 1
#      - 오른쪽 자식 : 2  i + 2
#      - 부모 노드 : (i - 1) / 2 (단, i > 0)

class ArrayBinaryTree:
    def __init__(self, max_size):
        # 배열을 None으로 초기화
        self.tree = [None] * max_size
        self.max_size = max_size
        self.size = 0  # 현재 노드의 개수

    def insert(self, value, index=0):

        """특정 인덱스에 값을 삽입 (완전 이진 트리를 가정하고 레벨 순서로 삽입하는 것은 별도 로직 필요)"""
        if index >= self.max_size:
            print(f"오류: 인덱스 {index}는 배열 크기를 초과합니다.")
            return

        self.tree[index] = value
        if value is not None:
            self.size = max(self.size, index + 1) # 배열 크기 갱신

    def get_root(self):
        return self.tree[0]

    def get_left_child(self, index):
        left_idx = 2 * index + 1
        if left_idx < self.size:
            return self.tree[left_idx]
        return None

    def get_right_child(self, index):
        right_idx = 2 * index + 2
        if right_idx < self.size:
            return self.tree[right_idx]
        return None

# --- 사용 예시 ---
# A(0) -> B(1), C(2)
# B(1) -> D(3), E(4)

tree_size = 7
abt = ArrayBinaryTree(tree_size)

abt.insert("A", 0)
abt.insert("B", 1)
abt.insert("C", 2)
abt.insert("D", 3)
abt.insert("E", 4)

# 인덱스 5는 None으로 비워두고, 인덱스 6에 F 삽입
abt.insert(None, 5) 
abt.insert("F", 6)

print(f"배열 표현: {abt.tree[:abt.size]}") 
print(f"루트 노드: {abt.get_root()}")
print(f"노드 'B'의 왼쪽 자식 (인덱스 3): {abt.get_left_child(1)}")
print(f"노드 'C'의 오른쪽 자식 (인덱스 6): {abt.get_right_child(2)}")

# 이진 검색 트리 (BST) 삽입 및 탐색 코드
# 이진 검색 트리 (BST)는 노드 기반(Node-based)으로 구현되며, 
# 모든 노드에 대해 다음과 같은 규칙을 만족함
#      - 왼쪽 서브 트리의 값은 노드의 값보다 작음
#      - 오른쪽 서브 트리의 값은 노드의 값보다 큼
#
# Node 및 BST 클래스 정의

class Node:
    """BST의 노드를 표현하는 클래스"""
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert(self, key):
        """BST에 새로운 키를 삽입하는 공개 메서드"""
        self.root = self._insert_recursive(self.root, key)

    def _insert_recursive(self, node, key):
        """키를 삽입하기 위해 재귀적으로 탐색하는 내부 메서드"""
        if node is None:
            return Node(key)
        
        # 1. 값이 작으면 왼쪽으로 이동
        if key < node.key:
            node.left = self._insert_recursive(node.left, key)

        # 2. 값이 크면 오른쪽으로 이동
        elif key > node.key:
            node.right = self._insert_recursive(node.right, key)
            
        # 3. (중복 값은 무시)
        return node
    
    def search(self, key):
        """BST에서 주어진 키를 탐색하는 공개 메서드"""
        return self._search_recursive(self.root, key)

    def _search_recursive(self, node, key):
        """키를 탐색하기 위해 재귀적으로 이동하는 내부 메서드"""
        # 1. 노드가 없거나 키를 찾았을 때
        if node is None or node.key == key:
            return node # 찾으면 노드를 반환, 못 찾으면 None 반환
        
        # 2. 키가 현재 노드의 값보다 작으면 왼쪽으로
        if key < node.key:
            return self._search_recursive(node.left, key)
        # 3. 키가 현재 노드의 값보다 크면 오른쪽으로
        else:
            return self._search_recursive(node.right, key)

# 사용 예시

bst = BinarySearchTree()

keys_to_insert = [50, 30, 70, 20, 40, 60, 80]

for key in keys_to_insert:
    bst.insert(key)

# --- 탐색 테스트 ---
# 존재하는 키 탐색
result_found = bst.search(40)
print(f"40 탐색 결과: {'찾음' if result_found else '못 찾음'} (노드 값: {result_found.key if result_found else 'N/A'})")

# 존재하지 않는 키 탐색
result_not_found = bst.search(99)
print(f"99 탐색 결과: {'찾음' if result_not_found else '못 찾음'}")