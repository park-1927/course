# 이진 검색 트리 (BST) 삽입 및 탐색 

# 이진 검색 트리 (BST)는 노드 기반(Node-based)으로 구현되며, 
# 모든 노드에 대해 다음과 같은 규칙을 만족함
#      - 왼쪽 서브 트리의 값은 노드의 값보다 작음
#      - 오른쪽 서브 트리의 값은 노드의 값보다 큼
#
# Node 및 BST 클래스 정의

class Node:

    """BST의 노드를 표현하는 클래스"""
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert(self, key):
        """BST에 새로운 키를 삽입하는 공개 메서드"""
        self.root = self._insert_recursive(self.root, key)

    def _insert_recursive(self, node, key):
        """키를 삽입하기 위해 재귀적으로 탐색하는 내부 메서드"""
        if node is None:
            return Node(key)
        
        # 1. 값이 작으면 왼쪽으로 이동
        if key < node.key:
            node.left = self._insert_recursive(node.left, key)

        # 2. 값이 크면 오른쪽으로 이동
        elif key > node.key:
            node.right = self._insert_recursive(node.right, key)
            
        # 3. (중복 값은 무시)
        return node
    
    def search(self, key):
        """BST에서 주어진 키를 탐색하는 공개 메서드"""
        return self._search_recursive(self.root, key)

    def _search_recursive(self, node, key):
        """키를 탐색하기 위해 재귀적으로 이동하는 내부 메서드"""

        # 1. 노드가 없거나 키를 찾았을 때
        if node is None or node.key == key:
            return node # 찾으면 노드를 반환, 못 찾으면 None 반환
        
        # 2. 키가 현재 노드의 값보다 작으면 왼쪽으로
        if key < node.key:
            return self._search_recursive(node.left, key)
        # 3. 키가 현재 노드의 값보다 크면 오른쪽으로
        else:
            return self._search_recursive(node.right, key)

# 사용 예시

bst = BinarySearchTree()

keys_to_insert = [50, 30, 70, 20, 40, 60, 80]

for key in keys_to_insert:
    bst.insert(key)

# --- 탐색 테스트 ---
# 존재하는 키 탐색

result_found = bst.search(40)
print(f"40 탐색 결과: {'찾음' if result_found else '못 찾음'} (노드 값: {result_found.key if result_found else 'N/A'})")

# 존재하지 않는 키 탐색

result_not_found = bst.search(99)
print(f"99 탐색 결과: {'찾음' if result_not_found else '못 찾음'}")