class Node:
    def __init__(self, key):
        self.left = None
        self.right = None
        self.val = key

def insert(root, key):

    # 1. 트리가 비어있으면 (공백 이진 트리), 새 노드가 루트가 됨
    if root is None:
        return Node(key)
    
    # 2. BST 규칙에 따라 왼쪽 또는 오른쪽으로 이동

    if key < root.val:
        # 왼쪽 서브트리로 재귀 호출
        root.left = insert(root.left, key)
    elif key > root.val:
        # 오른쪽 서브트리로 재귀 호출
        root.right = insert(root.right, key)
    
    # 삽입 후 루트 노드를 반환
    return root

# 초기 빈 트리 (공백 이진 트리)
root = None

# 임의의 노드 값들을 삽입하여 BST 구성
data = [50, 30, 70, 20, 40, 60, 80]

for value in data:
    root = insert(root, value)

# root 변수에 최종 BST의 루트 노드가 저장

# 구성된 BST 출력

def inorder_traversal(root):
    if root:
        # 1. 왼쪽으로 이동 (재귀 호출)
        inorder_traversal(root.left)
        
        # 2. 현재 노드의 값 출력
        print(root.val, end=" ")
        
        # 3. 오른쪽으로 이동 (재귀 호출)
        inorder_traversal(root.right)

print("--- 중위 순회 (오름차순) ---")
inorder_traversal(root)
print()