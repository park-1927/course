import os      #파일 시스템 상호작용을 위한 파이썬의 표준 모듈

def print_directory_tree(startpath):

# 주어진 경로에서 시작하여 파일 시스템의 디렉토리 트리를 출력
    print(startpath) # 시작 경로 출력

# os.walk를 사용하여 디렉토리를 순회 - 재귀적으로 디렉토리 트리를 탐색하며, 각 디렉토리마다 다음 세 가지 정보를 담은 튜플을 생성
# os.walk()는 파이썬의 os 모듈에서 제공하는 함수로, 지정한 디렉토리부터 시작하여 모든 하위 디렉토리까지 재귀적으로 탐색하는 역할
# 호출될 때마다 튜플 형태의 3가지 정보를 제너레이터로 반환

# top-down 방식을 사용하며, root, dirs, files를 반환
# ROOT - 현재 디렉토리의 경로 문자열
# dirs - root에 있는 서브 디렉토리 이름의 리스트
# files - root에 있는 파일 이름의 리스트

# startpath로 시작하는 디렉토리 구조를 한 단계씩 내려가면서(또는 올라가면서, 
# 기본 설정은 위에서 아래로) 모든 디렉토리와 그 안의 파일 목록을 순차적으로 얻어와 
# root, dirs, files 변수에 할당

    for root, dirs, files in os.walk(startpath):

# 현재 디렉토리가 시작 경로와 같은 경우 건너뛰어 중복 출력을 방지
        if root == startpath:
            continue

# 1. 들여쓰기 수준 계산

# 현재 경로(root)에서 시작 경로를 제거한 후, 경로 구분자(os.sep)의 개수를 세어 레벨을 파악
# level 계산 - root.replace(startpath, '').count(os.sep)를 사용하여 현재 디렉토리가
# 시작 디렉토리로부터 얼마나 깊이 들어갔는지 (트리의 레벨)를 계산(os.sep은 운영체제별
# 경로 구분자, Windows는 \)

        level = root.replace(startpath, '').count(os.sep)

# 2. 시각적 들여쓰기 문자열 생성

# 레벨당 4칸의 공백으로 들여씀
# indent 생성 - 레벨에 비례하는 공백 문자열을 만들어 들여쓰기를 표현

        indent = ' ' * 4 * level

# 디렉토리 및 파일 출력 : 계산된 indent와 트리를 시각적으로 나타내는 문자(├──, └──)를
# 사용하여 각 디렉토리와 파일을 출력

# 3. 현재 디렉토리 출력
# print('{}{}/'.format(indent, os.path.basename(root)))
# 깔끔한 출력을 위해 '├──' 등의 트리에디션 문자를 사용하는 것이 좋지만,
# 여기서는 os.walk의 간단함을 위해 들여쓰기만 사용합니다.
        print(f'{indent}├── {os.path.basename(root)}/')

# 4. 파일 들여쓰기 및 출력
        sub_indent = ' ' * 4 * (level + 1)
        for f in files:
                print(f'{sub_indent}└── {f}')

# 실행 방법
# 실제 파일 시스템을 탐색하므로, 테스트를 위해 작은 폴더 경로를 지정
# 예제 코드가 실행되는 현재 디렉토리(.)를 시작 경로로 지정(실제 사용 시에는 원하는 경로로 변경!!1)
# 예: start_directory = '/Users/사용자이름/Documents/MyProject'

start_directory = 'C:/Windows/System32/cmd.exe'
start_directory = os.getcwd()

print(start_directory)
print("--- 파일 시스템 디렉토리 트리 구조 예제 ---")

print(f"시작 경로: {start_directory}")

try:
    print_directory_tree(start_directory)

except Exception as e:

    print(f"\n[오류 발생] 디렉토리를 탐색하는 중 오류가 발생했습니다: {e}")
    print("권한 문제나 존재하지 않는 경로일 수 있습니다. 시작 경로를 확인해주세요.")